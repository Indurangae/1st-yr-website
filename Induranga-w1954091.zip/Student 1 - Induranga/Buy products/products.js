let shop = document.getElementById("shop");

 /* Shop items with details */       
let shopItemsData = [
{
    id: "product1",
    name:"Official T-Shirt",
    price: 20,
    desc: "SLC Men's T20 World Cup Cricket Fan T Shirt - Blue - Short Sleeve - SportX",
    img: "images/Shirt.jpg",
},
{
    id: "product2",
    name:"Official Cap",
    price: 10,
    desc: "Sri Lanka Cricket Cap T20 Original MAS - Blue - Casual - Cotton",
    img: "images/cap.jpg",
},
{
    id: "product3",
    name:"Bats",
    price: 60,
    desc: "Kookaburra Beast Pro Premium quality English Willow Cricket bat",
    img: "images/bat.jpg",
},
{
    id: "product4",
    name:"Balls",
    price: 45,
    desc: "Kookaburra County Star Cricket Ball, Red - Mens and Youths",
    img: "images/ball.jpg",
},
{
    id: "product5",
    name:"Posters",
    price: 20,
    desc: "SLC Team Wall Art Craft Paper Retro Poster 60CM*40CM",
    img: "images/poster.jpg",
},
{
    id: "product6",
    name:"Stickers",
    price: 5,
    desc: "Sri Lanka Cricket Player Decal Sticker 8CM*6CM - Waterproof",
    img: "images/stickers.jpg",
},
];

let basket = JSON.parse(localStorage.getItem("data")) || []; 

/* display shop items and buttons */
let generateShop = () => {
    return (shop.innerHTML = shopItemsData.map((x)=>{
        let {id, name, price, desc, img } = x;
        let search = basket.find ((x)=>x.id === id) || []
        return `
        <div id=product-id-${id} class="item">
                <img width="219" src=${img} alt="">
                <div class="details">
                    <h3>${name}</h3>
                    <p>${desc}</p>
                    <div class="price">
                        <h2>$ ${price}</h2>
                        <div class="buttons">
                            <i onclick="decrement(${id})" class="bi bi-dash-lg"></i>
                            <div id=${id} class="quantity">
                            ${search.item === undefined ? 0 : search.item}
                            </div>
                            <i onclick="increment(${id})" class="bi bi-plus-lg"></i>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join(""));
};

generateShop();

/* increasing the item quantity */
let increment = (id) => {
    let selectedItem = id;
    let search = basket.find((x)=> x.id === selectedItem.id);

    if(search === undefined){
        basket.push({
            id: selectedItem.id,
            item: 1,
        })
    }
    else {
        search.item += 1;
    }
    update(selectedItem.id);

    localStorage.setItem("data", JSON.stringify(basket));
};

/* decreasing the item quantity */
let decrement = (id) => {
    let selectedItem = id;
    let search = basket.find((x)=> x.id === selectedItem.id);

    if (search === undefined) return;
    else if(search.item === 0) return;
    else {
        search.item -= 1;
    }
    update(selectedItem.id);

    basket = basket.filter((x) => x.item !== 0);
    
    localStorage.setItem("data", JSON.stringify(basket));
};

/* update quantity when refresh */
let update = (id) => {
    let search = basket.find((x) => x.id === id );
    document.getElementById(id).innerHTML = search.item;
    calculation();
};

let calculation = () => {
    let cartIcon = document.getElementById("cartAmount");
    cartIcon.innerHTML = basket.map((x) => x.item) .reduce((x, y) => x + y, 0);
};

calculation();

/* navigation bar */

const body = document.querySelector("body");
const navbar = document.querySelector(".navbar");
const menuBtn = document.querySelector(".menu-btn");
const cancelBtn = document.querySelector(".cancel-btn");


menuBtn.onclick = ()=>{
  navbar.classList.add("show");
  menuBtn.classList.add("hide");
  body.classList.add("disabled");
}

cancelBtn.onclick = ()=>{
  body.classList.remove("disabled");
  navbar.classList.remove("show");
  menuBtn.classList.remove("hide");
}

window.onscroll = ()=>{
  this.scrollY > 20 ? navbar.classList.add("sticky") : navbar.classList.remove("sticky");
}
