 /* Shop items with details */
let shopItemsData = [
    {
        id: "product1",
        name:"Official T-Shirt",
        price: 20,
        desc: "SLC Men's T20 World Cup Cricket Fan T Shirt - Blue - Short Sleeve - SportX",
        img: "images/Shirt.jpg",
    },
    {
        id: "product2",
        name:"Official Cap",
        price: 10,
        desc: "Sri Lanka Cricket Cap T20 Original MAS - Blue - Casual - Cotton",
        img: "images/cap.jpg",
    },
    {
        id: "product3",
        name:"Bats",
        price: 60,
        desc: "Kookaburra Beast Pro Premium quality English Willow Cricket bat",
        img: "images/bat.jpg",
    },
    {
        id: "product4",
        name:"Balls",
        price: 45,
        desc: "Kookaburra County Star Cricket Ball, Red - Mens and Youths",
        img: "images/ball.jpg",
    },
    {
        id: "product5",
        name:"Posters",
        price: 20,
        desc: "SLC Team Wall Art Craft Paper Retro Poster 60CM*40CM",
        img: "images/poster.jpg",
    },
    {
        id: "product6",
        name:"Stickers",
        price: 5,
        desc: "Sri Lanka Cricket Player Decal Sticker 8CM*6CM - Waterproof",
        img: "images/stickers.jpg",
    },
    ];

let label = document.getElementById("label");
let ShoppingCart = document.getElementById("shopping-cart");
let basket = JSON.parse(localStorage.getItem("data")) || [];

let calculation = () => {
    let cartIcon = document.getElementById("cartAmount");
    cartIcon.innerHTML = basket.map((x) => x.item) .reduce((x, y) => x + y, 0);
};

calculation();

/* display cart items and buttons */
let generateCartItems = () => {
    if (basket.length !== 0) {
        return (ShoppingCart.innerHTML = basket
            .map ((x)=>{
                let { id, item } = x;
                let search = shopItemsData.find((y)=>y.id === id) || [];
                let { img, name, price } = search;
            return `
            <div class="cart-item">
                <img width="100" src=${img} alt="" />
                <div class="details">

                    <div class="title-price-x">
                        <h4 class="title-price">
                            <p>${name}</p>
                            <p class="cart-item-price">$ ${price}</p>
                        </h4>
                        <i onclick="removeItem(${id})" class="bi bi-x-lg"></i>
                    </div>
                    
                    <div class="buttons">
                        <i onclick="decrement(${id})" class="bi bi-dash-lg"></i>
                        <div id=${id} class="quantity">${item}</div>
                        <i onclick="increment(${id})" class="bi bi-plus-lg"></i>
                    </div>
                    
                    <h3>$ ${item * search.price}</h3>
                </div>
            </div>
            `;
        })
        .join(""));
    } else {
        ShoppingCart.innerHTML = ``;
        label.innerHTML = `
        <h2>Your cart is empty</h2>
        <a href="products.html">
            <button class="StoreBtn">Back to store</button>
        </a>
        `;
    }
};

generateCartItems();

/* increasing the item quantity */
let increment = (id) => {
    let selectedItem = id;
    let search = basket.find((x)=> x.id === selectedItem.id);

    if(search === undefined){
        basket.push({
            id: selectedItem.id,
            item: 1,
        })
    }
    else {
        search.item += 1;
    }
    generateCartItems();
    update(selectedItem.id);
    localStorage.setItem("data", JSON.stringify(basket));
};

/* decreasing the item quantity */
let decrement = (id) => {
    let selectedItem = id;
    let search = basket.find((x)=> x.id === selectedItem.id);

    if (search === undefined) return;
    else if(search.item === 0) return;
    else {
        search.item -= 1;
    }
    update(selectedItem.id);
    basket = basket.filter((x) => x.item !== 0);
    generateCartItems();
    localStorage.setItem("data", JSON.stringify(basket));
};

/* update quantity when refresh */
let update = (id) => {
    let search = basket.find((x) => x.id === id );
    document.getElementById(id).innerHTML = search.item;
    calculation();
    TotalAmount();
};

/* close button function */
let removeItem = (id) => {
    let selectedItem = id;
    basket = basket.filter((x) => x.id !== selectedItem.id);
    generateCartItems();
    TotalAmount();
    calculation();
    localStorage.setItem("data", JSON.stringify(basket));

};

/* clear button function */
let clearCart = ()=> {
    basket = [];
    generateCartItems();
    calculation();
    localStorage.setItem("data", JSON.stringify(basket));
};

/* buynow button function */
let buynow = ()=> {
	document.getElementById("payment").style.display = "block";
};

/* display total bill */
let TotalAmount = () => {
    if (basket/length !== 0) {
        let amount = basket
            .map((x) => {
                let { item, id } = x;
                let search = shopItemsData.find((y)=>y.id === id) || [];
                return item * search.price;
            })
            .reduce((x,y)=> x + y, 0);
        label.innerHTML = `
        <h2>Total price : $ ${amount}</h2>
        <button onclick="buynow()" class="buynow">Buy Now</button>
        <button onclick="clearCart()" class="clearAll">Clear cart</button>
        `;
    } else return;
};

TotalAmount();

/* navigation bar */

const body = document.querySelector("body");
const navbar = document.querySelector(".navbar");
const menuBtn = document.querySelector(".menu-btn");
const cancelBtn = document.querySelector(".cancel-btn");
menuBtn.onclick = ()=>{
  navbar.classList.add("show");
  menuBtn.classList.add("hide");
  body.classList.add("disabled");
};
cancelBtn.onclick = ()=>{
  body.classList.remove("disabled");
  navbar.classList.remove("show");
  menuBtn.classList.remove("hide");
};
window.onscroll = ()=>{
  this.scrollY > 20 ? navbar.classList.add("sticky") : navbar.classList.remove("sticky");
};
